package exercise_5_4.state;

public interface State {
	State parking();
	State depart();
}

package exercise_3_6;

public class Motor implements Parkable {

	public Motor(String plate, int width) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getWidth() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getPlate() {
		// TODO Auto-generated method stub
		return null;
	}

}

package exercise_3_6;

public class Lot {

	private int number;
	private int width;
	
	public Lot(int num, int width) {
		this.number = num;
		this.width = width;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getNumber() {
		return number;		
	}
}

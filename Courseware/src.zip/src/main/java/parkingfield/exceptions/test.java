package parkingfield.exceptions;
import parkingfield.*;
public class test {
	public static void main(String[] args) {
		Record rd=new Record(null, null);
	}
}
